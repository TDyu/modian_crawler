"""
Provides Twisted version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update Twisted` to change this file.

from incremental import Version

__version__ = Version('Twisted', 17, 5, 0)
__all__ = ["__version__"]
